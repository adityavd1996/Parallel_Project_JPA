
/*
 *Author      :  Aditya Vikram Dandapat
 *Application :  Bank Management System
 *Interface  :   DAOInter
 */

package com.bank.dao;

import java.util.List;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.exceprtion.CustomerNotFound;


	public interface DaoInter {
	public boolean addCustomer(Customer c) throws CustomerNotFound;
	
	public boolean validateAmount(Double withdraw);
//	public  void updateCustomer(Customer c,int amount) throws CustomerNotFound;
	public  Customer getCustomerDetails(int accNumber2,String email,int pin)throws CustomerNotFound;
	/*public boolean validatedeposit(int deposit);*/
	//public int showBalance(Customer c,int accNumber1);
	// public boolean fundTransfer( String email3, int accNumber3, int pin3,Customer a,Customer b, String email4,int accNumber4,int amount);
	//public boolean verifyAcc(String email4, int accNumber4);
	
	public boolean deposit(Customer customer)  throws CustomerNotFound;
	public boolean withdraw(Customer c) throws CustomerNotFound;
				
	 
	 public boolean verifyAccno(int accNumber4,String email4) throws CustomerNotFound;
	 public boolean fundTransfer(Customer customer1,Customer customer2)
				throws CustomerNotFound; 
	 public boolean verifyDetails(String email1, int accNumber1, int pin1)throws CustomerNotFound;
	 public Double showBalance(int accNumber1)throws CustomerNotFound;
	 
	 //public boolean printTransaction(int accNumber4)throws CustomerNotFound;
	public List<Passbook> printTransaction(int accountNumber) throws CustomerNotFound;
	public Customer getCust(int accNumber) throws CustomerNotFound;
}
