package com.bank.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/*
 *Author      :  Aditya Vikram Dandapat
 *Application :  Bank Management System
 *Class Name  :  Passbook
 */

@Entity
@Table(name="passbook")
public class Passbook implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int transactionId;
	
	private String transactionDetails;
	
	@ManyToOne
	@JoinColumn(name="Customer")
	private Customer customer;
	
	public Passbook() {
		
	}
public Passbook(int transactionId,

String transactionDetails,Customer customer) {
	this.transactionId=transactionId;

	this.transactionDetails=transactionDetails;
	this.customer=customer;

}
		
	
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionDetails() {
		return transactionDetails;
	}
	public void setTransactionDetails(String transactionDetails) {
		transactionDetails = transactionDetails;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public Passbook(Integer transactionId,
			String transactionDetails,Customer customer) {
		super();
		this.transactionId = transactionId;

		transactionDetails = transactionDetails;
	 this.customer=customer;
	}
	
	
}
