package com.bank.exceprtion;

public class CustomerNotFound extends Exception {
public CustomerNotFound(String msg)
{
	super(msg);
}

public CustomerNotFound()
{
	super();
}


public void getMessage(String string) {
	
	// TODO Auto-generated method stub
	System.out.println("Wrong Input!!!");
	
}

@Override
public String toString() {
	return "CustomerNotFound []";
}

}
